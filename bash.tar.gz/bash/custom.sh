##
# custom.sh
#
# anything that shouldn't be done on every machine
#

case `hostname | sed 's/\..*//'` in
	##
	# my machines
	#
	spoon)
		osascript -e "tell application \"Terminal\" to close window 1"
		clear;
		for ((i=0; i<=24; i++)); do echo; done;
		;;

	# fedora core boxes
	pavement|spoon-fc6)
		# oracle env stuff
		export ORACLE_HOME=/opt/oracle/product/10.1.0.3/instantclient
		export LD_LIBRARY_PATH=$ORACLE_HOME/lib
		export NLS_LANG=AMERICAN_AMERICA.UTF8
		;;

	##
	# snocap machines, web servers
	#
	allin|d2|d7|stuff|vanilli)
		# do nothing special
		;;

esac