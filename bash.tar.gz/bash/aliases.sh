##
# aliases.sh
#
# system aliases
#

alias ls='ls -G'
alias l='ls -hGF'
alias ll='l -o'
alias llg='l -l'
alias sl='ls'

alias screen='screen -dr >/dev/null || screen'

alias ..="cd .."

function scd() {
    if [ -z "$1" ]; then
        echo "Usage: scd <branch>" >&2
        return 1;
    fi

    NEW_DIR=`pwd | sed -r -e "s/(trunk|wa[0-9]+)/$1/"` 

    if [ -d "$NEW_DIR" ] ; then
        cd "$NEW_DIR"
    else
        echo "Invalid dir: $NEW_DIR" >&2
        return 1;
    fi
    return 0;
}

